<?php

use App\Http\Controllers\useController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/welcome', function () {
    return view('welcome');
});
Route::get('/', function () {
    return view('home');
});
Route::get('/acceuil', function () {
    return view('acceuil');
});
Route::get('/apropos', function () {
    return view('apropos');
});
Route::get('/service', function () {
    return view('service');

});
Route::get('/acceuil', [useController::class, 'store'])->name('acceuil');
Route::get('/apropos', [useController::class, 'store'])->name('apropos');
Route::get('/service', [useController::class, 'store'])->name('service');



/*Route::get('/contact', function () {
    return view('contact');
});*/
Route::get('/contact', 'App\Http\Controllers\useController@create')->name('contact');
Route::post('/contact', 'App\Http\Controllers\useController@store');
/*Route::get('/contact', [useController::class, 'create']);
Route::get('/contact', [useController::class, 'store'])->name('contact');*/

