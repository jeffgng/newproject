<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('css/cont.css')); ?>">
   <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">-->

    <title>nouveau</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
</head>

<body>
    <div class="container">
    <form  action="" method="POST" action="<?php echo e(action('App\Http\Controllers\useController@create')); ?>  ">
    <?php echo csrf_field(); ?>
        <div class="formulaire"> 
        <br>
            <label for="nom">name</label>
            <input type="text" name="name" id="name" required></br>
        <br>
            <label for="email">email</label>
            <input type="email" name="email" id="email" required></br>
        <br>
            <label for="message">message</label>
            <textarea name="message" id="" cols="30" rows="10" required></textarea></br>
        <br>
        <div class="contient">
            <button type="submit" name="envoyer">Envoyer</button>
        </div>
        </div>
    </form>
    </div>
    <footer class="page-footer>

            <p>copyright tout droit reserver</p>
            <div class=" container">
        <div class="row">
        <div class="col l6 s12">
            <h5>Footer Content</h5>
            <p>You can use rows and columns here to organize your footer content.</p>
        </div>
        <div class="row">
            <h5></h5>
            <div >
            <ul class="flex">
                <li><a href="<?php echo e(route('acceuil')); ?>">acceuil</a></li>
                <li><a href="<?php echo e(route('service')); ?>">Service</a></li>
                <li><a href="<?php echo e(route('apropos')); ?>">apropos</a></li>
                <li><a href="<?php echo e(route('contact')); ?>">contact</a></li>
                </div>
            </ul>
        </div>
        </div>
        </div>
        <div class="footer-copyright">
        <div class="continu">
            © 2014 Copyright Text tout droit reserver
        </div>
    </div>
    </footer>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\newproject\resources\views/contact.blade.php ENDPATH**/ ?>