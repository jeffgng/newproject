
<?php /**PATH C:\laragon\www\newproject\resources\views/acceuil.blade.php ENDPATH**/ ?>