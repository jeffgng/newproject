<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="{{ asset('css/app.css') }}">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

        <title>nouveau</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    </head>
    <style>
        
    </style>
    <body>


        <br>
            <nav class="nav-extended">
                <div class="nav-wrapper">
                    
                    <ul class="right hide-on-med-and-down">
                        <li > <a href="{{url('/acceuil')}}">acceuil</a></li>
                        <li > <a href="{{url('/service')}}">Service</a></li>
                        <li > <a href="{{url('/apropos')}}">apropos</a></li>
                        <li > <a href="{{route('contact')}}">contact</a></li>
                    </ul>
                    
                    <h1>nouveau projet</h1>
                </div>

            </nav>

        <br>
        <section>
            <h2 >Presentation du travail a faire</h2>
            <br>
            <div class="page">
            <p>Faire une page home contenant un menu, une section de contenu et un footer</p>
            <p>creer une page contact contenant un formulaire nonm, email avec message et un bouton envoyer</p>
            </div>
        </section>
        <footer class="page-footer>

            <p>copyright tout droit reserver</p>
            <div class="container">
                <div class="row">
                    <div class="col l6 s12">
                        <h5 class="white-text">Footer Content</h5>
                        <p>You can use rows and columns here to organize your footer content.</p>
                    </div>
                    <div class="row">
                        <h5 ></h5>
                        <ul class="flex">
                            <li ><a class="blanche" href="{{ route('acceuil')}}">acceuil</a></li>
                            <li ><a class="blanche" href="{{  route('service')}}">Service</a></li>
                            <li ><a class="blanche" href="{{ route('apropos')}}">apropos</a></li>
                            <li> <a class="blanche" href="{{ route('contact')}}">contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="footer-copyright">
                <div class="container">
                    © 2014 Copyright Text tout droit reserver
                </div>
            </div>
        </footer>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    </body>
</html>
